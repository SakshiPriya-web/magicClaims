import { useParams } from "react-router-dom";
import { useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { ArrowLeft, FileUp, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { uploadInvoicePdf } from "../lib/invoiceService";

export default function RepairClaimDetail() {
  const { claimId } = useParams();
  const [status, setStatus] = useState("Pending");
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = (e) => {
    const uploaded = e.target.files[0];
    if (!uploaded) return;
    if (uploaded.type !== "application/pdf") {
      toast.error("Please upload a valid PDF file!");
      return;
    }
    setFile(uploaded);
    toast.success("Invoice uploaded successfully!");
  };

  const handleDelete = () => {
    setFile(null);
    toast.info("Invoice deleted.");
  };
  const handleUpload = async () => {
    if (!file) return;
    try {
      setIsUploading(true);
      const resp = await uploadInvoicePdf({
        repair_shop_id: "REPAIR_SHOP_123", // replace with real ID from login/session
        customer_id: "CUSTOMER_456", // replace with actual customer ID
        claim_id: claimId, // you already have this from useParams
        file,
      });
      toast.success(`Uploaded successfully! Invoice ID: ${resp.invoice_id}`);
      console.log("Server response:", resp);
    } catch (err) {
      console.error(err);
      toast.error("Upload failed. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSave = () => {
    toast.success(`Status updated to "${status}"`);
  };

  const handleBack = () => {
    window.location.href = "/repair-dashboard";
  };

  return (
    <div className="min-h-screen bg-gradient-to-tr from-indigo-50 via-purple-50 to-pink-50 p-6">
      <div className="max-w-3xl mx-auto">
        <Button
          variant="ghost"
          className="mb-4 flex items-center gap-2 text-indigo-700 hover:text-indigo-900"
          onClick={handleBack}
        >
          <ArrowLeft className="w-4 h-4" /> Back to Dashboard
        </Button>

        <Card className="bg-white/80 backdrop-blur-sm border border-gray-200 shadow-lg rounded-2xl">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-indigo-700">
              Claim Details – {claimId}
            </CardTitle>
          </CardHeader>

          <CardContent className="space-y-6 text-gray-700">
            <div className="text-sm space-y-1">
              <p>
                <strong>Customer:</strong> Sakshi Priya
              </p>
              <p>
                <strong>Car:</strong> Honda Civic 2020
              </p>
              <p>
                <strong>Damage Type:</strong> Rear Bumper
              </p>
              <p>
                <strong>Estimated Cost:</strong> ₹18,000
              </p>
            </div>

            {/* Upload Section */}
            <div>
              <Label>Upload Invoice (PDF)</Label>
              <div className="flex items-center gap-3 mt-2">
                <Input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  disabled={status !== "Completed"}
                  className={
                    status !== "Completed"
                      ? "opacity-50 cursor-not-allowed"
                      : ""
                  }
                />
                <Button
                  disabled={!file || status !== "Completed" || isUploading}
                  className="flex items-center gap-2"
                  onClick={handleUpload}
                >
                  <FileUp className="w-4 h-4" />
                  {isUploading ? "Uploading..." : "Upload"}
                </Button>
              </div>

              {status !== "Completed" && (
                <p className="text-xs text-gray-500 mt-1">
                  Upload option will activate once the claim status is set to{" "}
                  <strong>Completed</strong>.
                </p>
              )}

              {file && status === "Completed" && (
                <div className="mt-3 border-t pt-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">{file.name}</span>
                    <Button
                      size="icon"
                      variant="destructive"
                      onClick={handleDelete}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <embed
                    src={URL.createObjectURL(file)}
                    type="application/pdf"
                    width="100%"
                    height="400px"
                    className="rounded-lg border border-gray-300 mt-3"
                  />
                </div>
              )}
            </div>

            {/* Update Status */}
            <div>
              <Label>Update Claim Status</Label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="mt-2 w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-400"
              >
                <option>Pending</option>
                <option>In Progress</option>
                <option>Completed</option>
              </select>
            </div>

            <Button className="w-full mt-4" onClick={handleSave}>
              Save Changes
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
