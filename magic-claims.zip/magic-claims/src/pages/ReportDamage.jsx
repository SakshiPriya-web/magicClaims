import { useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Calendar } from "../components/ui/calendar";
import { Shield, Upload, X, CalendarIcon, LogOut, Car } from "lucide-react";
import { format } from "date-fns";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

const ReportDamage = () => {
  const navigate = useNavigate();
  const [incidentDate, setIncidentDate] = useState(null);
  const [incidentTime, setIncidentTime] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [images, setImages] = useState([]);

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const newImages = files.map((file) => ({
      id: Date.now() + Math.random(),
      file,
      preview: URL.createObjectURL(file),
      description: "",
    }));
    setImages([...images, ...newImages]);
  };

  const removeImage = (id) => {
    setImages(images.filter((img) => img.id !== id));
  };

  const updateImageDescription = (id, description) => {
    setImages(
      images.map((img) => (img.id === id ? { ...img, description } : img))
    );
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!incidentDate || !incidentTime) {
      toast.error("Please select incident date and time");
      return;
    }
    if (!location) {
      toast.error("Please enter the incident location");
      return;
    }
    if (!description) {
      toast.error("Please provide an incident description");
      return;
    }
    if (images.length === 0) {
      toast.error("Please upload at least one image of the damage");
      return;
    }

    const claimId = "CLM-" + Date.now();
    toast.success("Claim submitted successfully! Redirecting...");

    // Navigate to ClaimSubmitted page with all data
    navigate("/claim-submitted", {
      state: {
        claimId,
        incidentDate: format(incidentDate, "PPP"),
        incidentTime,
        location,
        description,
        images: images.map((img) => img.file),
      },
    });
  };

  const handleLogout = () => {
    toast.success("Logged out successfully");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between cursor-pointer" onClick={() => navigate("/home")}>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold">magicClaims</h1>
                <p className="text-sm text-muted-foreground">
                  Policy Holder Portal
                </p>
              </div>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Card className="mb-6 border-primary/20 bg-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Car className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg mb-1">
                  Your Insured Vehicle
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mt-3">
                  <div>
                    <p className="text-muted-foreground">Make</p>
                    <p className="font-medium">Toyota</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Model</p>
                    <p className="font-medium">Camry</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Year</p>
                    <p className="font-medium">2022</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Trim</p>
                    <p className="font-medium">SE</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">Report Vehicle Damage</CardTitle>
            <CardDescription>
              Please provide detailed information about the incident and upload
              photos of the damage
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 col-span-1">
                  <Label>Incident Date *</Label>
                  <Calendar
                    mode="single"
                    selected={incidentDate}
                    onSelect={setIncidentDate}
                    initialFocus
                    className="pointer-events-auto p-2 border rounded shadow w-auto bg-white"
                    disabled={(date) => date > new Date()}
                  />
                </div>
                <div className="space-y-2 col-span-1">
                  <Label htmlFor="time">Incident Time *</Label>
                  <Input
                    id="time"
                    type="time"
                    value={incidentTime}
                    onChange={(e) => setIncidentTime(e.target.value)}
                    required
                    className="h-11 p-2 border rounded shadow w-auto bg-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Incident Location/Address *</Label>
                <Input
                  id="location"
                  placeholder="e.g., 123 Main Street, City, State, ZIP"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                  className="h-11 border rounded p-2 shadow w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Incident Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Please describe what happened, how the damage occurred, and any other relevant details..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                  rows={4}
                  className="resize-none border rounded p-2 w-full"
                />
              </div>

              <div className="space-y-4">
                <div>
                  <Label>Damage Photos *</Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Upload clear photos of all damaged areas. You can add
                    descriptions for each photo.
                  </p>
                </div>

                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                  />
                  <label
                    htmlFor="image-upload"
                    className="cursor-pointer flex flex-col items-center gap-2"
                  >
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Upload className="w-8 h-8 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Click to upload images</p>
                      <p className="text-sm text-muted-foreground">
                        PNG, JPG up to 10MB each
                      </p>
                    </div>
                  </label>
                </div>

                {images.length > 0 && (
                  <div className="space-y-4">
                    {images.map((image) => (
                      <Card key={image.id} className="overflow-hidden">
                        <div className="flex flex-col md:flex-row gap-4 p-4">
                          <div className="relative w-full md:w-48 h-48 flex-shrink-0">
                            <img
                              src={image.preview}
                              alt="Damage"
                              className="w-full h-full object-cover rounded-lg"
                            />
                            <button
                              type="button"
                              onClick={() => removeImage(image.id)}
                              className="absolute top-2 right-2 p-1.5 bg-destructive text-destructive-foreground rounded-full hover:bg-destructive/90 transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                          <div className="flex-1 space-y-2">
                            <Label htmlFor={`desc-${image.id}`}>
                              Photo Description
                            </Label>
                            <Textarea
                              id={`desc-${image.id}`}
                              placeholder="Describe what this photo shows..."
                              value={image.description}
                              onChange={(e) =>
                                updateImageDescription(image.id, e.target.value)
                              }
                              rows={5}
                              className="resize-none w-full"
                            />
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    if (
                      window.confirm(
                        "Are you sure you want to cancel? All data will be lost."
                      )
                    ) {
                      navigate("/home");
                    }
                  }}
                >
                  Cancel
                </Button>

                <Button type="submit" className="flex-1 h-11">
                  Submit Claim
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ReportDamage;
