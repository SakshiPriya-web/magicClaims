import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Shield, Car, LogOut, User, List } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();

  const cars = [
    {
      id: 1,
      make: "Toyota",
      model: "Camry",
      year: 2022,
      trim: "SE",
      policy: "AXZ-12345",
      expiry: "12 June 2026",
      status: "Active",
    },
    {
      id: 2,
      make: "Hyundai",
      model: "Creta",
      year: 2021,
      trim: "SX",
      policy: "BXZ-67890",
      expiry: "30 April 2025",
      status: "Renewal Due",
    },
  ];

  const handleLogout = () => {
    toast.success("Logged out successfully");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate("/home")}>
            <div className="p-2 bg-primary/10 rounded-lg">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold">magicClaims</h1>
              <p className="text-sm text-muted-foreground">Policy Holder Portal</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={() => navigate("/tracking")}>
              <List className="w-4 h-4 mr-1" />
              Track Claims
            </Button>
            <Button variant="outline" onClick={() => navigate("/profile")}>
              <User className="w-4 h-4 mr-1" />
              Profile
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-1" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-6">My Insured Vehicles</h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {cars.map((car) => (
            <Card
              key={car.id}
              className="shadow-md hover:shadow-lg transition-shadow"
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>
                    {car.make} {car.model}
                  </CardTitle>
                  <Car className="w-5 h-5 text-primary" />
                </div>
                <CardDescription>
                  {car.year} • {car.trim}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-2 text-sm">
                <p>
                  <span className="text-muted-foreground">Policy:</span>{" "}
                  {car.policy}
                </p>
                <p>
                  <span className="text-muted-foreground">Expiry:</span>{" "}
                  {car.expiry}
                </p>
                <p>
                  <span className="text-muted-foreground">Status:</span>{" "}
                  <span className="font-medium">{car.status}</span>
                </p>

                <div className="pt-3">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => navigate("/report-damage")}
                  >
                    Report Damage
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
