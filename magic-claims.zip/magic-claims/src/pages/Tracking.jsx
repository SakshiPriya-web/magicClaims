import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Shield, FileText, CheckCircle, Clock, XCircle, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

const Tracking = () => {
  const navigate = useNavigate();

  const claims = [
    {
      id: "C-12345",
      vehicle: "Toyota Camry",
      date: "5 Oct 2025",
      status: "Under Review",
      description: "Front bumper damage after minor collision"
    },
    {
      id: "C-12346",
      vehicle: "Hyundai Creta",
      date: "20 Sep 2025",
      status: "Approved",
      description: "Broken rear light after parking hit"
    },
    {
      id: "C-12347",
      vehicle: "Toyota Camry",
      date: "1 Aug 2025",
      status: "Rejected",
      description: "Scratches on door panel not covered"
    }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case "Approved":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "Under Review":
        return <Clock className="w-5 h-5 text-yellow-600" />;
      case "Rejected":
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const handleLogout = () => {
    toast.success("Logged out successfully");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold">magicClaims</h1>
              <p className="text-sm text-muted-foreground">Claim Tracking</p>
            </div>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <h2 className="text-2xl font-bold mb-6">My Claims</h2>
        {claims.map((claim) => (
          <Card key={claim.id} className="mb-4 shadow-md hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Claim ID: {claim.id}</CardTitle>
                <CardDescription>{claim.vehicle} • {claim.date}</CardDescription>
              </div>
              {getStatusIcon(claim.status)}
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-2">{claim.description}</p>
              <p className="font-medium">
                Status:{" "}
                <span
                  className={
                    claim.status === "Approved"
                      ? "text-green-600"
                      : claim.status === "Under Review"
                      ? "text-yellow-600"
                      : "text-red-600"
                  }
                >
                  {claim.status}
                </span>
              </p>
            </CardContent>
          </Card>
        ))}
        <div className="mt-6">
          <Button variant="outline" onClick={() => navigate("/home")}>
            Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Tracking;
