import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Wrench, LogOut, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

export default function RepairDashboard() {
  const [search, setSearch] = useState("");
  const [claims] = useState([
    { id: "CLM001", customer: "Sakshi Priya", car: "Honda Civic 2020", status: "Pending" },
    { id: "CLM002", customer: "Rohan Verma", car: "Hyundai Creta 2019", status: "Completed" },
    { id: "CLM003", customer: "Aditi Sharma", car: "Maruti Swift 2021", status: "In Progress" },
  ]);

  const filteredClaims = claims.filter(
    (c) =>
      c.id.toLowerCase().includes(search.toLowerCase()) ||
      c.customer.toLowerCase().includes(search.toLowerCase())
  );

  const handleLogout = () => {
    localStorage.removeItem("user");
    toast.success("Logged out successfully!");
    window.location.href = "/"; // since no navigate
  };

  return (
    <div className="min-h-screen bg-gradient-to-tr from-indigo-50 via-purple-50 to-pink-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Wrench className="w-6 h-6 text-indigo-600" />
            </div>
            <h1 className="text-2xl font-bold text-indigo-700">
              Repair Shop Dashboard
            </h1>
          </div>

          <Button
            variant="outline"
            className="flex items-center gap-2 border-gray-300 text-gray-700 hover:bg-gray-100"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4" /> Logout
          </Button>
        </div>

        {/* Search Bar */}
        <div className="flex items-center gap-2 mb-6">
          <Input
            placeholder="Search by Claim ID or Customer"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-11"
          />
          <Button className="h-11 flex items-center gap-2">
            <Search className="w-4 h-4" /> Search
          </Button>
        </div>

        {/* Claims List */}
        <div className="grid md:grid-cols-2 gap-6">
          {filteredClaims.map((claim) => (
            <Link key={claim.id} to={`/repair/claims/${claim.id}`}>
              <Card
                className="cursor-pointer bg-white/80 backdrop-blur-sm border border-gray-200 shadow-lg hover:shadow-xl hover:scale-[1.01] transition rounded-2xl"
              >
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-indigo-700">
                    Claim ID: {claim.id}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm text-gray-700">
                  <p><strong>Customer:</strong> {claim.customer}</p>
                  <p><strong>Car:</strong> {claim.car}</p>
                  <p><strong>Status:</strong> <span className="font-medium">{claim.status}</span></p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
