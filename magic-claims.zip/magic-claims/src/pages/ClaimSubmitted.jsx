import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { CheckCircle } from "lucide-react";

const ClaimSubmitted = () => {
  const navigate = useNavigate();
  const { state } = useLocation(); // Data passed from ReportDamage page

  const claimId = state?.claimId || "CLM-" + Date.now();
  const incidentDate = state?.incidentDate || "N/A";
  const incidentTime = state?.incidentTime || "N/A";
  const location = state?.location || "N/A";
  const description = state?.description || "N/A";
  const images = state?.images || [];

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
      <Card className="max-w-2xl w-full shadow-lg rounded-2xl border border-gray-200">
        <CardHeader className="text-center">
          <CheckCircle className="mx-auto text-green-600 w-12 h-12" />
          <CardTitle className="text-2xl font-semibold mt-2">
            Claim Submitted Successfully
          </CardTitle>
          <p className="text-gray-500 mt-1">
            Your claim ID is <span className="font-semibold">{claimId}</span>
          </p>
        </CardHeader>

        <CardContent className="space-y-4 text-gray-700">
          <div>
            <p><span className="font-medium">Incident Date:</span> {incidentDate}</p>
            <p><span className="font-medium">Incident Time:</span> {incidentTime}</p>
            <p><span className="font-medium">Location:</span> {location}</p>
            <p><span className="font-medium">Description:</span> {description}</p>
          </div>

          {images.length > 0 && (
            <div>
              <p className="font-medium mb-2">Uploaded Photos:</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {images.map((img, index) => (
                  <img
                    key={index}
                    src={URL.createObjectURL(img)}
                    alt={`Uploaded ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg border"
                  />
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-center gap-3 pt-4">
            <Button onClick={() => navigate("/home")}>Back to Home</Button>
            <Button variant="outline" onClick={() => navigate("/tracking")}>
              Track Claims
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClaimSubmitted;
