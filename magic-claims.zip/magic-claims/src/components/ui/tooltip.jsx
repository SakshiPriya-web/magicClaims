// src/components/ui/tooltip.jsx
export const TooltipProvider = ({ children }) => <>{children}</>;
