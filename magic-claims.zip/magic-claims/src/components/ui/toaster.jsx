// src/components/ui/toaster.jsx
export const Toaster = () => null;
