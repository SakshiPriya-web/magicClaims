// src/components/ui/sonner.jsx
export const Toaster = () => null;
